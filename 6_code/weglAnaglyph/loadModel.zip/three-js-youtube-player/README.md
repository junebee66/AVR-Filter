# Three.js YouTube player

A Pen created on CodePen.io. Original URL: [https://codepen.io/asjas/pen/pWawPm](https://codepen.io/asjas/pen/pWawPm).

This is my first workings with Three.js. I used the same player as on the three.js documentation page.